import Foundation

var line = (readLine()?.split(separator: " "))!;
var s = [19, 10, 12, 10, 24, 25, 22]
var k = Int(line[4])!
var arrTemp = (readLine()?.split(separator: " "))!
var set = arrTemp.compactMap({Int($0)!})
var remainderCounter : [Int] = Array.init(repeating: 0, count: k)
var result = 0;

for i in set{
    remainderCounter[i%k]+=1;
}


if remainderCounter[0] > 1 {
    result+=1;
}


if k % 2 == 0 {result+=1;}

for i in 1..<k/2+1{
    for s in i+2..<k{
        if i + s == k{
            result += max(remainderCounter[i], remainderCounter[s]);
        }
    }
}

print(result == 0 ? 1 : result)


//
//
////  Another way
//
//
//let S = [19, 10, 12, 10, 24, 25, 22]
//var k = [4]
//var remainderCounter : [Int] = line.type(of:;; init)(repeating: 0, count: k)
//var result = 0;
//
//for index in 0..<line.count {
//    for nextIndex in (index + 1)..<line.count {
//        for thirdIndex in (nextIndex + 1)..<line.count {
//
//
//
//for i in set{
//    remainderCounter[i%k]+=1;
//}
//
//
//if remainderCounter[0] > 1 {
//    result+=1;
//}
//
//
//if k % 2 == 0 {result+=1;}
//
//for i in 1..<k/2+1{
//    for s in i+1..<k{
//        if i + s == k{
//            result += max(remainderCounter[i], remainderCounter[s]);
//        }
//    }
//}
//
//print(result == 0 ? 1 : result)
//
//
//
//            print(Array[index] + Array[nextIndex] + Array[thirdIndex] )
//
//    }
//}
//}
